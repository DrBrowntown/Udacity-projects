# Local Map

Udacity project with google maps and Wikipedia API.

## Instructions:
* Extract files.
* Open index.html

## Features:
* Google map loaded from Maps API.
* Map markers located at Points of Interest
* Points of Interest markers can be filtered via buttons in the sidebar
* Markers show information and wikipedia links for the chosen place when clicked.

## Attributions:
* Google Maps API
(https://developers.google.com/maps/)
* Wikipedia API
(https://www.mediawiki.org/wiki/API:Main_page)
* Bootstrap
(https://startbootstrap.com/template-overviews/simple-sidebar) 
* Snazzy Maps
(https://snazzymaps.com)
