// These are the search listings that will be shown to the user.

  var locations = [
    {type: 'museum-search', title: 'New York City&Brooklyn musuems'},
    {type: 'restaurant-search', title: 'New York City restaurants'},
    {type: 'bar-search', title: 'New York City Bars'},
    {type: 'shop-search', title: 'New York City Shops'}
  ];